import { UserPreferences, Neighborhood, MatchResult, ScoreBreakdown } from '../types';

/**
 * Core matching algorithm that calculates neighborhood compatibility scores
 * Based on weighted factors and user preferences
 */
export class NeighborhoodMatcher {
  private static readonly WEIGHTS = {
    lifestyle: 0.3,
    demographics: 0.2,
    amenities: 0.2,
    transportation: 0.15,
    housing: 0.1,
    safety: 0.05
  };

  /**
   * Calculate match score for a neighborhood based on user preferences
   */
  static calculateMatch(preferences: UserPreferences, neighborhood: Neighborhood): MatchResult {
    const breakdown: ScoreBreakdown = {
      lifestyle: this.calculateLifestyleScore(preferences, neighborhood),
      demographics: this.calculateDemographicsScore(preferences, neighborhood),
      amenities: this.calculateAmenitiesScore(preferences, neighborhood),
      transportation: this.calculateTransportationScore(preferences, neighborhood),
      housing: this.calculateHousingScore(preferences, neighborhood),
      safety: this.calculateSafetyScore(preferences, neighborhood)
    };

    const totalScore = Object.entries(breakdown).reduce((sum, [key, score]) => {
      return sum + (score * this.WEIGHTS[key as keyof typeof this.WEIGHTS]);
    }, 0);

    const reasons = this.generateMatchReasons(preferences, neighborhood, breakdown);

    return {
      neighborhood,
      score: Math.round(totalScore * 100) / 100,
      breakdown,
      reasons
    };
  }

  /**
   * Calculate lifestyle compatibility score
   */
  private static calculateLifestyleScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    let score = 0;
    let factors = 0;

    // Social level matching
    const socialScore = this.normalizeScore(neighborhood.lifestyle.nightlifeScore, 10);
    score += this.calculatePreferenceMatch(preferences.lifestyle.socialLevel, socialScore * 5, 5);
    factors++;

    // Activity level matching
    const activityScore = this.normalizeScore(neighborhood.lifestyle.outdoorActivities, 10);
    score += this.calculatePreferenceMatch(preferences.lifestyle.activityLevel, activityScore * 5, 5);
    factors++;

    // Nightlife preference
    if (preferences.lifestyle.nightlife) {
      score += this.normalizeScore(neighborhood.lifestyle.nightlifeScore, 10);
      factors++;
    }

    // Family orientation
    if (preferences.lifestyle.familyOriented) {
      score += this.normalizeScore(neighborhood.lifestyle.familyFriendliness, 10);
      factors++;
    }

    // Pet friendliness
    if (preferences.lifestyle.petFriendly) {
      score += this.normalizeScore(neighborhood.lifestyle.petFriendliness, 10);
      factors++;
    }

    // Outdoor activities
    if (preferences.lifestyle.outdoorActivities) {
      score += this.normalizeScore(neighborhood.lifestyle.outdoorActivities, 10);
      factors++;
    }

    return factors > 0 ? score / factors : 0;
  }

  /**
   * Calculate demographics compatibility score
   */
  private static calculateDemographicsScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    let score = 0;
    let factors = 0;

    // Age range matching (simplified)
    const ageRanges = {
      '18-25': 22,
      '26-35': 30,
      '36-45': 40,
      '46-55': 50,
      '56+': 60
    };

    const userAge = ageRanges[preferences.demographics.ageRange as keyof typeof ageRanges] || 35;
    const ageDifference = Math.abs(userAge - neighborhood.demographics.medianAge);
    score += Math.max(0, 1 - (ageDifference / 20)); // Normalize age difference
    factors++;

    // Income compatibility
    const incomeRanges = {
      'under-30k': 25000,
      '30k-50k': 40000,
      '50k-75k': 62500,
      '75k-100k': 87500,
      '100k-150k': 125000,
      'over-150k': 175000
    };

    const userIncome = incomeRanges[preferences.demographics.incomeRange as keyof typeof incomeRanges] || 75000;
    const incomeDifference = Math.abs(userIncome - neighborhood.demographics.medianIncome);
    score += Math.max(0, 1 - (incomeDifference / 100000)); // Normalize income difference
    factors++;

    return factors > 0 ? score / factors : 0;
  }

  /**
   * Calculate amenities score based on user preferences
   */
  private static calculateAmenitiesScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    let score = 0;
    let factors = 0;

    // Base amenities everyone needs
    score += this.normalizeScore(neighborhood.amenities.restaurants, 100) * 0.2;
    score += this.normalizeScore(neighborhood.amenities.shopping, 50) * 0.2;
    score += this.normalizeScore(neighborhood.amenities.hospitals, 5) * 0.1;
    factors += 0.5;

    // Family-specific amenities
    if (preferences.demographics.hasChildren || preferences.lifestyle.familyOriented) {
      score += this.normalizeScore(neighborhood.amenities.schools, 20) * 0.3;
      score += this.normalizeScore(neighborhood.amenities.parks, 20) * 0.2;
      factors += 0.5;
    }

    // Activity-based amenities
    if (preferences.lifestyle.activityLevel >= 3) {
      score += this.normalizeScore(neighborhood.amenities.gyms, 20) * 0.2;
      score += this.normalizeScore(neighborhood.amenities.parks, 20) * 0.1;
      factors += 0.3;
    }

    // Social amenities
    if (preferences.lifestyle.socialLevel >= 3) {
      score += this.normalizeScore(neighborhood.amenities.cafes, 50) * 0.15;
      score += this.normalizeScore(neighborhood.amenities.restaurants, 100) * 0.1;
      factors += 0.25;
    }

    // Nightlife amenities
    if (preferences.lifestyle.nightlife) {
      score += this.normalizeScore(neighborhood.amenities.nightlife, 30) * 0.3;
      factors += 0.3;
    }

    return factors > 0 ? score / factors : 0;
  }

  /**
   * Calculate transportation score
   */
  private static calculateTransportationScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const transportationPrefs = preferences.lifestyle.transportationMode;
    
    switch (transportationPrefs) {
      case 'walk':
        return this.normalizeScore(neighborhood.transportation.walkScore, 100);
      case 'public_transit':
        return this.normalizeScore(neighborhood.transportation.transitScore, 100);
      case 'bike':
        return this.normalizeScore(neighborhood.transportation.bikeScore, 100);
      case 'car':
        return Math.max(0, 1 - (neighborhood.transportation.commuteTime / 60)); // Prefer shorter commutes
      case 'mixed':
        return (
          this.normalizeScore(neighborhood.transportation.walkScore, 100) * 0.3 +
          this.normalizeScore(neighborhood.transportation.transitScore, 100) * 0.3 +
          this.normalizeScore(neighborhood.transportation.bikeScore, 100) * 0.2 +
          Math.max(0, 1 - (neighborhood.transportation.commuteTime / 60)) * 0.2
        );
      default:
        return 0.5; // Default neutral score
    }
  }

  /**
   * Calculate housing affordability score
   */
  private static calculateHousingScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const incomeRanges = {
      'under-30k': 25000,
      '30k-50k': 40000,
      '50k-75k': 62500,
      '75k-100k': 87500,
      '100k-150k': 125000,
      'over-150k': 175000
    };

    const userIncome = incomeRanges[preferences.demographics.incomeRange as keyof typeof incomeRanges] || 75000;
    const affordableRent = userIncome * 0.3 / 12; // 30% of income rule
    
    // Score based on affordability
    const affordabilityScore = Math.max(0, Math.min(1, affordableRent / neighborhood.housing.rentPrice));
    
    return affordabilityScore;
  }

  /**
   * Calculate safety score
   */
  private static calculateSafetyScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    return this.normalizeScore(neighborhood.safety.safetyScore, 10);
  }

  /**
   * Generate human-readable match reasons
   */
  private static generateMatchReasons(
    preferences: UserPreferences, 
    neighborhood: Neighborhood, 
    breakdown: ScoreBreakdown
  ): string[] {
    const reasons: string[] = [];

    // Lifestyle reasons
    if (breakdown.lifestyle > 0.7) {
      if (preferences.lifestyle.nightlife && neighborhood.lifestyle.nightlifeScore > 7) {
        reasons.push(`Great nightlife scene with ${neighborhood.amenities.nightlife} venues`);
      }
      if (preferences.lifestyle.familyOriented && neighborhood.lifestyle.familyFriendliness > 7) {
        reasons.push(`Very family-friendly with ${neighborhood.amenities.schools} schools and ${neighborhood.amenities.parks} parks`);
      }
      if (preferences.lifestyle.petFriendly && neighborhood.lifestyle.petFriendliness > 7) {
        reasons.push('Excellent pet-friendly environment');
      }
    }

    // Transportation reasons
    if (breakdown.transportation > 0.7) {
      if (preferences.lifestyle.transportationMode === 'walk' && neighborhood.transportation.walkScore > 80) {
        reasons.push(`Highly walkable (Walk Score: ${neighborhood.transportation.walkScore})`);
      }
      if (preferences.lifestyle.transportationMode === 'public_transit' && neighborhood.transportation.transitScore > 70) {
        reasons.push(`Excellent public transit access (Transit Score: ${neighborhood.transportation.transitScore})`);
      }
    }

    // Amenities reasons
    if (breakdown.amenities > 0.6) {
      if (neighborhood.amenities.restaurants > 50) {
        reasons.push(`Rich dining scene with ${neighborhood.amenities.restaurants} restaurants`);
      }
      if (neighborhood.amenities.cafes > 30) {
        reasons.push(`Vibrant café culture with ${neighborhood.amenities.cafes} coffee shops`);
      }
    }

    // Safety reasons
    if (breakdown.safety > 0.7) {
      reasons.push(`Safe neighborhood (Safety Score: ${neighborhood.safety.safetyScore}/10)`);
    }

    return reasons.slice(0, 4); // Limit to top 4 reasons
  }

  /**
   * Utility function to normalize scores to 0-1 range
   */
  private static normalizeScore(value: number, max: number): number {
    return Math.min(1, Math.max(0, value / max));
  }

  /**
   * Calculate how well a preference matches a neighborhood characteristic
   */
  private static calculatePreferenceMatch(userPref: number, neighborhoodValue: number, scale: number): number {
    const difference = Math.abs(userPref - neighborhoodValue);
    return Math.max(0, 1 - (difference / scale));
  }
}