/**
 * Data processing pipeline for neighborhood data
 * Handles data collection, cleaning, normalization, and validation
 */

import { Neighborhood } from '../types';

export interface DataSource {
  name: string;
  url: string;
  updateFrequency: 'real-time' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annually';
  reliability: number; // 1-5 scale
  coverage: number; // percentage
}

export interface DataProcessingResult {
  success: boolean;
  processedCount: number;
  errors: string[];
  qualityScore: number;
  timestamp: Date;
}

export class DataProcessor {
  private static readonly DATA_SOURCES: DataSource[] = [
    {
      name: 'US Census Bureau',
      url: 'https://api.census.gov/data',
      updateFrequency: 'annually',
      reliability: 5,
      coverage: 100
    },
    {
      name: 'Walk Score API',
      url: 'https://api.walkscore.com',
      updateFrequency: 'quarterly',
      reliability: 4,
      coverage: 85
    },
    {
      name: 'Google Places API',
      url: 'https://maps.googleapis.com/maps/api/place',
      updateFrequency: 'real-time',
      reliability: 4,
      coverage: 90
    },
    {
      name: 'Crime Data APIs',
      url: 'https://data.seattle.gov/api',
      updateFrequency: 'monthly',
      reliability: 3,
      coverage: 75
    },
    {
      name: 'Housing Price APIs',
      url: 'https://api.rentals.com',
      updateFrequency: 'daily',
      reliability: 4,
      coverage: 95
    }
  ];

  /**
   * Process raw neighborhood data through cleaning and normalization pipeline
   */
  static async processNeighborhoodData(rawData: any[]): Promise<DataProcessingResult> {
    const errors: string[] = [];
    let processedCount = 0;
    let qualityScores: number[] = [];

    try {
      for (const item of rawData) {
        try {
          const processed = await this.processNeighborhoodItem(item);
          if (processed) {
            processedCount++;
            qualityScores.push(this.calculateDataQuality(processed));
          }
        } catch (error) {
          errors.push(`Failed to process item ${item.id}: ${error}`);
        }
      }

      const averageQuality = qualityScores.length > 0 
        ? qualityScores.reduce((a, b) => a + b, 0) / qualityScores.length 
        : 0;

      return {
        success: errors.length < rawData.length * 0.1, // Success if <10% errors
        processedCount,
        errors,
        qualityScore: averageQuality,
        timestamp: new Date()
      };
    } catch (error) {
      return {
        success: false,
        processedCount: 0,
        errors: [`Critical processing error: ${error}`],
        qualityScore: 0,
        timestamp: new Date()
      };
    }
  }

  /**
   * Process individual neighborhood data item
   */
  private static async processNeighborhoodItem(rawItem: any): Promise<Neighborhood | null> {
    // Data validation
    if (!this.validateRequiredFields(rawItem)) {
      throw new Error('Missing required fields');
    }

    // Data cleaning and normalization
    const cleaned = this.cleanData(rawItem);
    const normalized = this.normalizeData(cleaned);
    
    // Data enrichment (simulate API calls)
    const enriched = await this.enrichData(normalized);
    
    return enriched;
  }

  /**
   * Validate that required fields are present
   */
  private static validateRequiredFields(data: any): boolean {
    const required = ['id', 'name', 'city', 'state', 'coordinates'];
    return required.every(field => data[field] !== undefined && data[field] !== null);
  }

  /**
   * Clean and standardize data formats
   */
  private static cleanData(data: any): any {
    return {
      ...data,
      // Standardize text fields
      name: this.cleanText(data.name),
      city: this.cleanText(data.city),
      state: this.cleanText(data.state),
      
      // Ensure numeric fields are numbers
      coordinates: {
        lat: this.ensureNumber(data.coordinates?.lat),
        lng: this.ensureNumber(data.coordinates?.lng)
      },
      
      // Clean demographic data
      demographics: {
        medianAge: this.ensureNumber(data.demographics?.medianAge),
        medianIncome: this.ensureNumber(data.demographics?.medianIncome),
        populationDensity: this.ensureNumber(data.demographics?.populationDensity),
        diversityIndex: this.clampNumber(data.demographics?.diversityIndex, 0, 1),
        educationLevel: this.clampNumber(data.demographics?.educationLevel, 1, 5)
      }
    };
  }

  /**
   * Normalize data to consistent scales
   */
  private static normalizeData(data: any): any {
    return {
      ...data,
      // Normalize scores to 0-100 or 0-10 scales as appropriate
      transportation: {
        walkScore: this.clampNumber(data.transportation?.walkScore, 0, 100),
        transitScore: this.clampNumber(data.transportation?.transitScore, 0, 100),
        bikeScore: this.clampNumber(data.transportation?.bikeScore, 0, 100),
        commuteTime: Math.max(0, data.transportation?.commuteTime || 30)
      },
      
      safety: {
        crimeRate: Math.max(0, data.safety?.crimeRate || 0),
        safetyScore: this.clampNumber(data.safety?.safetyScore, 1, 10)
      },
      
      lifestyle: {
        walkability: this.clampNumber(data.lifestyle?.walkability, 1, 10),
        familyFriendliness: this.clampNumber(data.lifestyle?.familyFriendliness, 1, 10),
        nightlifeScore: this.clampNumber(data.lifestyle?.nightlifeScore, 1, 10),
        outdoorActivities: this.clampNumber(data.lifestyle?.outdoorActivities, 1, 10),
        culturalActivities: this.clampNumber(data.lifestyle?.culturalActivities, 1, 10),
        petFriendliness: this.clampNumber(data.lifestyle?.petFriendliness, 1, 10)
      }
    };
  }

  /**
   * Enrich data with additional API calls (simulated)
   */
  private static async enrichData(data: any): Promise<Neighborhood> {
    // Simulate API enrichment delay
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // In a real implementation, this would make actual API calls
    // to gather additional data like recent amenity counts, updated prices, etc.
    
    return {
      ...data,
      // Add computed fields
      lastUpdated: new Date().toISOString(),
      dataQualityScore: this.calculateDataQuality(data)
    } as Neighborhood;
  }

  /**
   * Calculate data quality score for a neighborhood
   */
  private static calculateDataQuality(data: any): number {
    let score = 0;
    let maxScore = 0;

    // Check completeness of each major section
    const sections = [
      'demographics',
      'amenities', 
      'transportation',
      'housing',
      'safety',
      'lifestyle'
    ];

    sections.forEach(section => {
      if (data[section]) {
        const sectionData = data[section];
        const fields = Object.keys(sectionData);
        const completedFields = fields.filter(field => 
          sectionData[field] !== null && 
          sectionData[field] !== undefined &&
          sectionData[field] !== 0
        );
        
        score += completedFields.length;
        maxScore += fields.length;
      }
    });

    return maxScore > 0 ? score / maxScore : 0;
  }

  /**
   * Utility functions for data cleaning
   */
  private static cleanText(text: string): string {
    if (!text) return '';
    return text.trim().replace(/\s+/g, ' ');
  }

  private static ensureNumber(value: any): number {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  }

  private static clampNumber(value: any, min: number, max: number): number {
    const num = this.ensureNumber(value);
    return Math.max(min, Math.min(max, num));
  }

  /**
   * Validate processed data meets quality standards
   */
  static validateProcessedData(neighborhoods: Neighborhood[]): {
    valid: boolean;
    issues: string[];
    qualityScore: number;
  } {
    const issues: string[] = [];
    let totalQuality = 0;

    neighborhoods.forEach((neighborhood, index) => {
      // Check for required fields
      if (!neighborhood.id || !neighborhood.name) {
        issues.push(`Neighborhood ${index}: Missing required identification fields`);
      }

      // Check coordinate validity
      if (!neighborhood.coordinates || 
          Math.abs(neighborhood.coordinates.lat) > 90 ||
          Math.abs(neighborhood.coordinates.lng) > 180) {
        issues.push(`Neighborhood ${neighborhood.name}: Invalid coordinates`);
      }

      // Check data ranges
      if (neighborhood.transportation.walkScore > 100 || neighborhood.transportation.walkScore < 0) {
        issues.push(`Neighborhood ${neighborhood.name}: Walk score out of range`);
      }

      // Calculate quality for this neighborhood
      const quality = this.calculateDataQuality(neighborhood);
      totalQuality += quality;

      if (quality < 0.7) {
        issues.push(`Neighborhood ${neighborhood.name}: Low data quality (${(quality * 100).toFixed(0)}%)`);
      }
    });

    return {
      valid: issues.length === 0,
      issues,
      qualityScore: neighborhoods.length > 0 ? totalQuality / neighborhoods.length : 0
    };
  }

  /**
   * Get data source information
   */
  static getDataSources(): DataSource[] {
    return [...this.DATA_SOURCES];
  }

  /**
   * Simulate data collection from external APIs
   */
  static async collectDataFromSources(): Promise<{
    success: boolean;
    data: any[];
    errors: string[];
  }> {
    // Simulate API calls with delays and potential failures
    const results = await Promise.allSettled(
      this.DATA_SOURCES.map(async (source) => {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, Math.random() * 1000));
        
        // Simulate occasional failures
        if (Math.random() < 0.1) {
          throw new Error(`Failed to fetch from ${source.name}`);
        }
        
        // Return mock data
        return {
          source: source.name,
          data: this.generateMockData(source),
          timestamp: new Date()
        };
      })
    );

    const successful = results.filter(r => r.status === 'fulfilled') as PromiseFulfilledResult<any>[];
    const failed = results.filter(r => r.status === 'rejected') as PromiseRejectedResult[];

    return {
      success: failed.length === 0,
      data: successful.map(r => r.value),
      errors: failed.map(r => r.reason.message)
    };
  }

  /**
   * Generate mock data for testing
   */
  private static generateMockData(source: DataSource): any {
    // Return different mock data based on source type
    switch (source.name) {
      case 'US Census Bureau':
        return {
          demographics: {
            medianAge: 25 + Math.random() * 40,
            medianIncome: 40000 + Math.random() * 100000,
            populationDensity: 1000 + Math.random() * 10000
          }
        };
      
      case 'Walk Score API':
        return {
          transportation: {
            walkScore: Math.random() * 100,
            transitScore: Math.random() * 100,
            bikeScore: Math.random() * 100
          }
        };
      
      default:
        return { mockData: true };
    }
  }
}