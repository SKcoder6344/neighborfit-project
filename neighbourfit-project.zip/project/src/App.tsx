import { useState } from 'react';
import { UserPreferences, MatchResult } from './types';
import { PreferenceForm } from './components/PreferenceForm';
import { NeighborhoodCard } from './components/NeighborhoodCard';
import { NeighborhoodDetails } from './components/NeighborhoodDetails';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ResearchDashboard } from './components/ResearchDashboard';
import { NeighborhoodMatcher } from './services/matchingAlgorithm';
import { sampleNeighborhoods } from './data/neighborhoods';
import { MapPin, Target, BarChart3, FlaskConical } from 'lucide-react';

type AppState = 'form' | 'loading' | 'results' | 'details' | 'research';

function App() {
  const [state, setState] = useState<AppState>('form');
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const [selectedMatch, setSelectedMatch] = useState<MatchResult | null>(null);

  const handlePreferencesSubmit = async (preferences: UserPreferences) => {
    setState('loading');
    
    // Simulate API delay for realistic UX
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Calculate matches using our algorithm
    const matchResults = sampleNeighborhoods
      .map(neighborhood => NeighborhoodMatcher.calculateMatch(preferences, neighborhood))
      .sort((a, b) => b.score - a.score);
    
    setMatches(matchResults);
    setState('results');
  };

  const handleViewDetails = (neighborhoodId: string) => {
    const match = matches.find(m => m.neighborhood.id === neighborhoodId);
    if (match) {
      setSelectedMatch(match);
      setState('details');
    }
  };

  const handleBackToResults = () => {
    setState('results');
    setSelectedMatch(null);
  };

  const handleStartOver = () => {
    setState('form');
    setMatches([]);
    setSelectedMatch(null);
  };

  const handleViewResearch = () => {
    setState('research');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="bg-primary-600 rounded-lg p-2 mr-3">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">NeighborFit</h1>
                <p className="text-sm text-gray-500">Find your perfect neighborhood match</p>
              </div>
            </div>
            
            {state !== 'form' && (
              <button
                onClick={handleStartOver}
                className="btn-secondary"
              >
                Start Over
              </button>
            )}
            
            {state === 'form' && (
              <button
                onClick={handleViewResearch}
                className="btn-secondary flex items-center"
              >
                <FlaskConical className="w-4 h-4 mr-2" />
                View Research
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {state === 'form' && (
          <>
            {/* Hero Section */}
            <div className="text-center mb-12">
              <div className="flex justify-center mb-6">
                <div className="bg-primary-100 rounded-full p-4">
                  <Target className="w-12 h-12 text-primary-600" />
                </div>
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Discover Your Ideal Neighborhood
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our advanced matching algorithm analyzes your lifestyle preferences, demographics, 
                and priorities to find neighborhoods that truly fit your needs.
              </p>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="bg-primary-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Data-Driven Analysis</h3>
                <p className="text-gray-600">
                  Real neighborhood data including demographics, amenities, transportation, and safety metrics
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-primary-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <Target className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Personalized Matching</h3>
                <p className="text-gray-600">
                  Advanced algorithm considers your unique lifestyle, work style, and personal priorities
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-primary-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Detailed Insights</h3>
                <p className="text-gray-600">
                  Comprehensive neighborhood profiles with match explanations and detailed breakdowns
                </p>
              </div>
            </div>

            <PreferenceForm onSubmit={handlePreferencesSubmit} />
          </>
        )}

        {state === 'loading' && <LoadingSpinner />}

        {state === 'results' && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Your Neighborhood Matches
              </h2>
              <p className="text-lg text-gray-600">
                Found {matches.length} neighborhoods ranked by compatibility
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {matches.map((match) => (
                <NeighborhoodCard
                  key={match.neighborhood.id}
                  match={match}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          </div>
        )}

        {state === 'details' && selectedMatch && (
          <NeighborhoodDetails
            match={selectedMatch}
            onBack={handleBackToResults}
          />
        )}

        {state === 'research' && <ResearchDashboard />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-500">
            <p className="mb-2">
              NeighborFit - A data-driven approach to neighborhood matching
            </p>
            <p className="text-sm">
              Built with real neighborhood data and advanced matching algorithms
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;