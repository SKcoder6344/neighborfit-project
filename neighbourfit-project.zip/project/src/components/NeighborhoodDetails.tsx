import React from 'react';
import { MatchResult } from '../types';
import { 
  ArrowLeft, 
  MapPin, 
  DollarSign, 
  Users, 
  Car, 
  Shield, 
  Home,
  ShoppingBag,
  Heart,
  TreePine,
  Moon
} from 'lucide-react';

interface NeighborhoodDetailsProps {
  match: MatchResult;
  onBack: () => void;
}

export const NeighborhoodDetails: React.FC<NeighborhoodDetailsProps> = ({ match, onBack }) => {
  const { neighborhood, score, breakdown } = match;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600';
    if (score >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const ScoreSection: React.FC<{ 
    title: string; 
    score: number; 
    icon: React.ReactNode;
    children: React.ReactNode;
  }> = ({ title, score, icon, children }) => (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          {icon}
          <h3 className="text-lg font-semibold text-gray-900 ml-2">{title}</h3>
        </div>
        <div className={`text-lg font-bold ${getScoreColor(score)}`}>
          {Math.round(score * 100)}%
        </div>
      </div>
      {children}
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <button
          onClick={onBack}
          className="flex items-center text-primary-600 hover:text-primary-700 mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Results
        </button>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {neighborhood.name}
            </h1>
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin className="w-5 h-5 mr-2" />
              <span className="text-lg">{neighborhood.city}, {neighborhood.state}</span>
            </div>
          </div>
          
          <div className="bg-primary-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-primary-600 mb-1">
              {Math.round(score * 100)}%
            </div>
            <div className="text-sm text-primary-700">Overall Match</div>
          </div>
        </div>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="card text-center">
          <DollarSign className="w-8 h-8 text-primary-600 mx-auto mb-2" />
          <div className="text-xl font-bold text-gray-900">
            {formatPrice(neighborhood.housing.rentPrice)}
          </div>
          <div className="text-sm text-gray-500">Average Rent</div>
        </div>

        <div className="card text-center">
          <Car className="w-8 h-8 text-primary-600 mx-auto mb-2" />
          <div className="text-xl font-bold text-gray-900">
            {neighborhood.transportation.walkScore}
          </div>
          <div className="text-sm text-gray-500">Walk Score</div>
        </div>

        <div className="card text-center">
          <Users className="w-8 h-8 text-primary-600 mx-auto mb-2" />
          <div className="text-xl font-bold text-gray-900">
            {formatNumber(neighborhood.demographics.populationDensity)}
          </div>
          <div className="text-sm text-gray-500">People per sq mi</div>
        </div>

        <div className="card text-center">
          <Shield className="w-8 h-8 text-primary-600 mx-auto mb-2" />
          <div className="text-xl font-bold text-gray-900">
            {neighborhood.safety.safetyScore}/10
          </div>
          <div className="text-sm text-gray-500">Safety Score</div>
        </div>
      </div>

      {/* Detailed Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Lifestyle */}
        <ScoreSection
          title="Lifestyle Fit"
          score={breakdown.lifestyle}
          icon={<Heart className="w-6 h-6 text-primary-600" />}
        >
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-sm text-gray-500">Walkability</div>
              <div className="text-lg font-semibold">{neighborhood.lifestyle.walkability}/10</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Family Friendliness</div>
              <div className="text-lg font-semibold">{neighborhood.lifestyle.familyFriendliness}/10</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Nightlife</div>
              <div className="text-lg font-semibold">{neighborhood.lifestyle.nightlifeScore}/10</div>
            </div>
            <div>
              <div className="text-sm text-gray-500">Pet Friendliness</div>
              <div className="text-lg font-semibold">{neighborhood.lifestyle.petFriendliness}/10</div>
            </div>
          </div>
        </ScoreSection>

        {/* Transportation */}
        <ScoreSection
          title="Transportation"
          score={breakdown.transportation}
          icon={<Car className="w-6 h-6 text-primary-600" />}
        >
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Walk Score</span>
              <span className="font-semibold">{neighborhood.transportation.walkScore}/100</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Transit Score</span>
              <span className="font-semibold">{neighborhood.transportation.transitScore}/100</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Bike Score</span>
              <span className="font-semibold">{neighborhood.transportation.bikeScore}/100</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Avg Commute</span>
              <span className="font-semibold">{neighborhood.transportation.commuteTime} min</span>
            </div>
          </div>
        </ScoreSection>

        {/* Amenities */}
        <ScoreSection
          title="Amenities"
          score={breakdown.amenities}
          icon={<ShoppingBag className="w-6 h-6 text-primary-600" />}
        >
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Restaurants</span>
              <span className="font-semibold">{neighborhood.amenities.restaurants}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Cafés</span>
              <span className="font-semibold">{neighborhood.amenities.cafes}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Parks</span>
              <span className="font-semibold">{neighborhood.amenities.parks}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Gyms</span>
              <span className="font-semibold">{neighborhood.amenities.gyms}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Schools</span>
              <span className="font-semibold">{neighborhood.amenities.schools}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shopping</span>
              <span className="font-semibold">{neighborhood.amenities.shopping}</span>
            </div>
          </div>
        </ScoreSection>

        {/* Demographics */}
        <ScoreSection
          title="Demographics"
          score={breakdown.demographics}
          icon={<Users className="w-6 h-6 text-primary-600" />}
        >
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Median Age</span>
              <span className="font-semibold">{neighborhood.demographics.medianAge} years</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Median Income</span>
              <span className="font-semibold">{formatPrice(neighborhood.demographics.medianIncome)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Education Level</span>
              <span className="font-semibold">{neighborhood.demographics.educationLevel}/5</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Diversity Index</span>
              <span className="font-semibold">{(neighborhood.demographics.diversityIndex * 100).toFixed(0)}%</span>
            </div>
          </div>
        </ScoreSection>

        {/* Housing */}
        <ScoreSection
          title="Housing"
          score={breakdown.housing}
          icon={<Home className="w-6 h-6 text-primary-600" />}
        >
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Median Home Price</span>
              <span className="font-semibold">{formatPrice(neighborhood.housing.medianPrice)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Average Rent</span>
              <span className="font-semibold">{formatPrice(neighborhood.housing.rentPrice)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Homeownership Rate</span>
              <span className="font-semibold">{(neighborhood.housing.homeOwnershipRate * 100).toFixed(0)}%</span>
            </div>
            <div>
              <span className="text-gray-600">Housing Types</span>
              <div className="mt-1">
                {neighborhood.housing.housingTypes.map((type, index) => (
                  <span
                    key={index}
                    className="inline-block bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs mr-2 mb-1"
                  >
                    {type.replace('_', ' ')}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </ScoreSection>

        {/* Safety */}
        <ScoreSection
          title="Safety"
          score={breakdown.safety}
          icon={<Shield className="w-6 h-6 text-primary-600" />}
        >
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Safety Score</span>
              <span className="font-semibold">{neighborhood.safety.safetyScore}/10</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Crime Rate</span>
              <span className="font-semibold">{neighborhood.safety.crimeRate} per 1,000</span>
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                {neighborhood.safety.safetyScore >= 8 
                  ? "Very safe neighborhood with low crime rates"
                  : neighborhood.safety.safetyScore >= 6
                  ? "Generally safe with typical urban precautions recommended"
                  : "Exercise normal urban safety precautions"
                }
              </p>
            </div>
          </div>
        </ScoreSection>
      </div>
    </div>
  );
};