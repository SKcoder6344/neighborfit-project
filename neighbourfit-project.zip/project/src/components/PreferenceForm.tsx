import React, { useState } from 'react';
import { UserPreferences, LifestylePreferences, Demographics } from '../types';
import { MapPin, Users, Home, Car, Heart, Star } from 'lucide-react';

interface PreferenceFormProps {
  onSubmit: (preferences: UserPreferences) => void;
  loading?: boolean;
}

export const PreferenceForm: React.FC<PreferenceFormProps> = ({ onSubmit, loading = false }) => {
  const [lifestyle, setLifestyle] = useState<LifestylePreferences>({
    workStyle: 'hybrid',
    transportationMode: 'mixed',
    socialLevel: 3,
    activityLevel: 3,
    nightlife: false,
    familyOriented: false,
    petFriendly: false,
    outdoorActivities: false,
  });

  const [demographics, setDemographics] = useState<Demographics>({
    ageRange: '26-35',
    incomeRange: '75k-100k',
    householdSize: 1,
    hasChildren: false,
    hasPets: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const preferences: UserPreferences = {
      lifestyle,
      demographics,
      priorities: [
        { factor: 'lifestyle', weight: 8 },
        { factor: 'transportation', weight: 7 },
        { factor: 'amenities', weight: 6 },
        { factor: 'safety', weight: 8 },
        { factor: 'housing', weight: 7 },
        { factor: 'demographics', weight: 5 },
      ]
    };

    onSubmit(preferences);
  };

  const ScaleInput: React.FC<{
    label: string;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    lowLabel: string;
    highLabel: string;
  }> = ({ label, value, onChange, min = 1, max = 5, lowLabel, highLabel }) => (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      <div className="flex items-center space-x-4">
        <span className="text-xs text-gray-500">{lowLabel}</span>
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
        />
        <span className="text-xs text-gray-500">{highLabel}</span>
      </div>
      <div className="text-center">
        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
          {value}/{max}
        </span>
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Find Your Perfect Neighborhood</h2>
        <p className="text-lg text-gray-600">
          Tell us about your lifestyle and preferences to get personalized neighborhood recommendations
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Lifestyle Preferences */}
        <div className="card">
          <div className="flex items-center mb-6">
            <Heart className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold text-gray-900">Lifestyle Preferences</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Work Style</label>
              <select
                value={lifestyle.workStyle}
                onChange={(e) => setLifestyle({ ...lifestyle, workStyle: e.target.value as any })}
                className="input-field"
              >
                <option value="remote">Fully Remote</option>
                <option value="hybrid">Hybrid (2-3 days office)</option>
                <option value="office">Full-time Office</option>
                <option value="flexible">Flexible Schedule</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Primary Transportation</label>
              <select
                value={lifestyle.transportationMode}
                onChange={(e) => setLifestyle({ ...lifestyle, transportationMode: e.target.value as any })}
                className="input-field"
              >
                <option value="walk">Walking</option>
                <option value="bike">Biking</option>
                <option value="public_transit">Public Transit</option>
                <option value="car">Car</option>
                <option value="mixed">Mixed Transportation</option>
              </select>
            </div>

            <ScaleInput
              label="Social Activity Level"
              value={lifestyle.socialLevel}
              onChange={(value) => setLifestyle({ ...lifestyle, socialLevel: value })}
              lowLabel="Homebody"
              highLabel="Very Social"
            />

            <ScaleInput
              label="Physical Activity Level"
              value={lifestyle.activityLevel}
              onChange={(value) => setLifestyle({ ...lifestyle, activityLevel: value })}
              lowLabel="Low Activity"
              highLabel="Very Active"
            />
          </div>

          <div className="mt-6">
            <p className="text-sm font-medium text-gray-700 mb-4">Important to you:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { key: 'nightlife', label: 'Nightlife & Entertainment' },
                { key: 'familyOriented', label: 'Family-Friendly' },
                { key: 'petFriendly', label: 'Pet-Friendly' },
                { key: 'outdoorActivities', label: 'Outdoor Activities' },
              ].map(({ key, label }) => (
                <label key={key} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={lifestyle[key as keyof LifestylePreferences] as boolean}
                    onChange={(e) => setLifestyle({ ...lifestyle, [key]: e.target.checked })}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span className="text-sm text-gray-700">{label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Demographics */}
        <div className="card">
          <div className="flex items-center mb-6">
            <Users className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold text-gray-900">Demographics</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Age Range</label>
              <select
                value={demographics.ageRange}
                onChange={(e) => setDemographics({ ...demographics, ageRange: e.target.value })}
                className="input-field"
              >
                <option value="18-25">18-25</option>
                <option value="26-35">26-35</option>
                <option value="36-45">36-45</option>
                <option value="46-55">46-55</option>
                <option value="56+">56+</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Household Income</label>
              <select
                value={demographics.incomeRange}
                onChange={(e) => setDemographics({ ...demographics, incomeRange: e.target.value })}
                className="input-field"
              >
                <option value="under-30k">Under $30,000</option>
                <option value="30k-50k">$30,000 - $50,000</option>
                <option value="50k-75k">$50,000 - $75,000</option>
                <option value="75k-100k">$75,000 - $100,000</option>
                <option value="100k-150k">$100,000 - $150,000</option>
                <option value="over-150k">Over $150,000</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Household Size</label>
              <input
                type="number"
                min="1"
                max="10"
                value={demographics.householdSize}
                onChange={(e) => setDemographics({ ...demographics, householdSize: parseInt(e.target.value) })}
                className="input-field"
              />
            </div>

            <div className="space-y-4">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={demographics.hasChildren}
                  onChange={(e) => setDemographics({ ...demographics, hasChildren: e.target.checked })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-sm text-gray-700">Have children</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={demographics.hasPets}
                  onChange={(e) => setDemographics({ ...demographics, hasPets: e.target.checked })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-sm text-gray-700">Have pets</span>
              </label>
            </div>
          </div>
        </div>

        <div className="text-center">
          <button
            type="submit"
            disabled={loading}
            className="btn-primary px-8 py-3 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Finding Matches...
              </div>
            ) : (
              <>
                <MapPin className="w-5 h-5 inline mr-2" />
                Find My Neighborhoods
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};