import React, { useState } from 'react';
import { researchData, ResearchAnalyzer } from '../data/researchData';
import { BarChart3, TrendingUp, Users, Target, Database, CheckCircle, XCircle } from 'lucide-react';

export const ResearchDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'validation' | 'competitive' | 'data'>('validation');

  const ValidationTab = () => (
    <div className="space-y-6">
      {/* Algorithm Performance */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Target className="w-6 h-6 text-primary-600 mr-3" />
          <h3 className="text-xl font-semibold text-gray-900">Algorithm Performance</h3>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">78%</div>
            <div className="text-sm text-gray-500">Prediction Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">84%</div>
            <div className="text-sm text-gray-500">Top-3 Hit Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">4.2min</div>
            <div className="text-sm text-gray-500">Avg Completion</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">4.1/5</div>
            <div className="text-sm text-gray-500">User Satisfaction</div>
          </div>
        </div>
      </div>

      {/* Hypothesis Testing Results */}
      <div className="card">
        <div className="flex items-center mb-4">
          <CheckCircle className="w-6 h-6 text-green-600 mr-3" />
          <h3 className="text-xl font-semibold text-gray-900">Hypothesis Validation</h3>
        </div>

        <div className="space-y-4">
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-gray-900">H1: Lifestyle vs Demographics</h4>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Lifestyle preferences are stronger predictors of satisfaction than demographic similarity
            </p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Lifestyle Correlation:</span>
                <span className="font-semibold ml-2">r = 0.79</span>
              </div>
              <div>
                <span className="text-gray-500">Demographic Correlation:</span>
                <span className="font-semibold ml-2">r = 0.52</span>
              </div>
            </div>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-gray-900">H2: Transportation Mode Impact</h4>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Primary transportation mode significantly influences preference weights
            </p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>Bike users: +35% bike infrastructure weight</div>
              <div>Transit users: +25% transit score weight</div>
              <div>Car users: +15% housing cost weight</div>
              <div>Walk users: +30% walkability weight</div>
            </div>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-gray-900">H3: Weighted vs Equal Scoring</h4>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Personalized weighted scoring produces more accurate matches
            </p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Weighted Algorithm:</span>
                <span className="font-semibold ml-2">4.2/5.0 satisfaction</span>
              </div>
              <div>
                <span className="text-gray-500">Equal Weight:</span>
                <span className="font-semibold ml-2">3.1/5.0 satisfaction</span>
              </div>
            </div>
            <div className="mt-2 text-sm">
              <span className="text-green-600 font-semibold">+34% improvement</span> in user acceptance
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const CompetitiveTab = () => (
    <div className="space-y-6">
      <div className="card">
        <div className="flex items-center mb-4">
          <TrendingUp className="w-6 h-6 text-primary-600 mr-3" />
          <h3 className="text-xl font-semibold text-gray-900">Competitive Landscape</h3>
        </div>

        <div className="space-y-4">
          {researchData.competitiveAnalysis.competitors.map((competitor, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-900">{competitor.name}</h4>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-500">
                    {(competitor.marketShare * 100).toFixed(0)}% market share
                  </span>
                  <span className="text-sm font-medium">
                    {competitor.userRating}/5.0 ⭐
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h5 className="text-sm font-medium text-green-700 mb-2">Strengths</h5>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {competitor.strengths.map((strength, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle className="w-3 h-3 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        {strength}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h5 className="text-sm font-medium text-red-700 mb-2">Market Gaps</h5>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {competitor.gaps.map((gap, i) => (
                      <li key={i} className="flex items-start">
                        <XCircle className="w-3 h-3 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                        {gap}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Market Opportunity</h3>
        <div className="bg-primary-50 rounded-lg p-4">
          <h4 className="font-medium text-primary-900 mb-2">Identified Gap</h4>
          <p className="text-primary-800 mb-4">
            {researchData.competitiveAnalysis.marketGap.identifiedOpportunity}
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h5 className="text-sm font-medium text-primary-900 mb-2">Target Market Size</h5>
              <p className="text-2xl font-bold text-primary-600">
                {(researchData.competitiveAnalysis.marketGap.targetMarketSize / 1000000).toFixed(1)}M
              </p>
              <p className="text-sm text-primary-700">Annual movers in target demographics</p>
            </div>
            
            <div>
              <h5 className="text-sm font-medium text-primary-900 mb-2">Competitive Advantages</h5>
              <ul className="text-sm text-primary-800 space-y-1">
                {researchData.competitiveAnalysis.marketGap.competitiveAdvantage.map((advantage, i) => (
                  <li key={i} className="flex items-start">
                    <CheckCircle className="w-3 h-3 text-primary-600 mr-2 mt-0.5 flex-shrink-0" />
                    {advantage}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const DataTab = () => {
    const qualityScore = ResearchAnalyzer.calculateDataQualityScore(researchData.dataQualityMetrics);
    
    return (
      <div className="space-y-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Database className="w-6 h-6 text-primary-600 mr-3" />
              <h3 className="text-xl font-semibold text-gray-900">Data Quality Overview</h3>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-primary-600">
                {(qualityScore * 100).toFixed(0)}%
              </div>
              <div className="text-sm text-gray-500">Overall Quality Score</div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Data Sources</h4>
            {researchData.dataQualityMetrics.dataSources.map((source, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium text-gray-900">{source.source}</h5>
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-500">{source.updateFrequency}</span>
                    <span className="text-sm font-medium">
                      {source.reliability}/5 reliability
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Coverage</span>
                      <span>{source.coverage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-primary-600 h-2 rounded-full"
                        style={{ width: `${source.coverage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Neighborhood Data Completeness</h3>
          <div className="space-y-3">
            {researchData.dataQualityMetrics.dataCompleteness.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-900">{item.neighborhood}</h4>
                  {item.missingFields.length > 0 && (
                    <p className="text-sm text-gray-500">
                      Missing: {item.missingFields.join(', ')}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-lg font-semibold text-gray-900">
                    {(item.completenessScore * 100).toFixed(0)}%
                  </div>
                  <div className="text-sm text-gray-500">Complete</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Research & Validation Dashboard</h1>
        <p className="text-lg text-gray-600">
          Comprehensive analysis of algorithm performance, competitive landscape, and data quality
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'validation', label: 'Algorithm Validation', icon: Target },
            { id: 'competitive', label: 'Competitive Analysis', icon: TrendingUp },
            { id: 'data', label: 'Data Quality', icon: Database },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="w-4 h-4 mr-2" />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'validation' && <ValidationTab />}
      {activeTab === 'competitive' && <CompetitiveTab />}
      {activeTab === 'data' && <DataTab />}
    </div>
  );
};