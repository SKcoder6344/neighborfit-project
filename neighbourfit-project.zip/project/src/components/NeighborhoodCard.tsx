import React from 'react';
import { MatchResult } from '../types';
import { MapPin, DollarSign, Users, Car, Shield, Star, TrendingUp } from 'lucide-react';

interface NeighborhoodCardProps {
  match: MatchResult;
  onViewDetails: (neighborhoodId: string) => void;
}

export const NeighborhoodCard: React.FC<NeighborhoodCardProps> = ({ match, onViewDetails }) => {
  const { neighborhood, score, breakdown, reasons } = match;

  const getScoreColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600 bg-green-100';
    if (score >= 0.6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const ScoreBar: React.FC<{ label: string; score: number; color?: string }> = ({ 
    label, 
    score, 
    color = 'bg-primary-500' 
  }) => (
    <div className="flex items-center justify-between text-sm">
      <span className="text-gray-600 min-w-0 flex-1">{label}</span>
      <div className="flex items-center ml-4">
        <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
          <div
            className={`h-2 rounded-full ${color}`}
            style={{ width: `${score * 100}%` }}
          ></div>
        </div>
        <span className="text-gray-700 font-medium min-w-[2rem] text-right">
          {Math.round(score * 100)}
        </span>
      </div>
    </div>
  );

  return (
    <div className="card hover:shadow-lg transition-shadow duration-200">
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-1">
            {neighborhood.name}
          </h3>
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{neighborhood.city}, {neighborhood.state}</span>
          </div>
        </div>
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getScoreColor(score)}`}>
          <div className="flex items-center">
            <Star className="w-4 h-4 mr-1" />
            {Math.round(score * 100)}% Match
          </div>
        </div>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <DollarSign className="w-4 h-4 text-gray-500" />
          </div>
          <div className="text-sm font-medium text-gray-900">
            {formatPrice(neighborhood.housing.rentPrice)}
          </div>
          <div className="text-xs text-gray-500">Avg Rent</div>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Car className="w-4 h-4 text-gray-500" />
          </div>
          <div className="text-sm font-medium text-gray-900">
            {neighborhood.transportation.walkScore}
          </div>
          <div className="text-xs text-gray-500">Walk Score</div>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Users className="w-4 h-4 text-gray-500" />
          </div>
          <div className="text-sm font-medium text-gray-900">
            {neighborhood.demographics.medianAge}
          </div>
          <div className="text-xs text-gray-500">Median Age</div>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center mb-1">
            <Shield className="w-4 h-4 text-gray-500" />
          </div>
          <div className="text-sm font-medium text-gray-900">
            {neighborhood.safety.safetyScore}/10
          </div>
          <div className="text-xs text-gray-500">Safety</div>
        </div>
      </div>

      {/* Match Breakdown */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-900 mb-3">Match Breakdown</h4>
        <div className="space-y-2">
          <ScoreBar label="Lifestyle" score={breakdown.lifestyle} />
          <ScoreBar label="Transportation" score={breakdown.transportation} />
          <ScoreBar label="Amenities" score={breakdown.amenities} />
          <ScoreBar label="Demographics" score={breakdown.demographics} />
          <ScoreBar label="Housing" score={breakdown.housing} />
          <ScoreBar label="Safety" score={breakdown.safety} />
        </div>
      </div>

      {/* Match Reasons */}
      {reasons.length > 0 && (
        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-900 mb-3">Why it's a good match:</h4>
          <ul className="space-y-1">
            {reasons.map((reason, index) => (
              <li key={index} className="text-sm text-gray-600 flex items-start">
                <TrendingUp className="w-3 h-3 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                {reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Action Button */}
      <button
        onClick={() => onViewDetails(neighborhood.id)}
        className="w-full btn-primary"
      >
        View Detailed Analysis
      </button>
    </div>
  );
};