import { Neighborhood } from '../types';

// Sample neighborhood data - In a real application, this would come from APIs
// Data sources: Census data, Walk Score API, local government data, etc.
export const sampleNeighborhoods: Neighborhood[] = [
  {
    id: '1',
    name: 'Capitol Hill',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6205, lng: -122.3212 },
    demographics: {
      medianAge: 32,
      medianIncome: 75000,
      populationDensity: 8500,
      diversityIndex: 0.7,
      educationLevel: 4
    },
    amenities: {
      restaurants: 85,
      cafes: 45,
      gyms: 12,
      parks: 8,
      schools: 6,
      hospitals: 2,
      shopping: 35,
      nightlife: 25
    },
    transportation: {
      walkScore: 88,
      transitScore: 72,
      bikeScore: 65,
      commuteTime: 25
    },
    housing: {
      medianPrice: 650000,
      rentPrice: 2200,
      homeOwnershipRate: 0.35,
      housingTypes: ['apartment', 'condo', 'townhouse']
    },
    safety: {
      crimeRate: 45,
      safetyScore: 6
    },
    lifestyle: {
      walkability: 9,
      familyFriendliness: 6,
      nightlifeScore: 9,
      outdoorActivities: 7,
      culturalActivities: 9,
      petFriendliness: 8
    }
  },
  {
    id: '2',
    name: 'Ballard',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6681, lng: -122.3834 },
    demographics: {
      medianAge: 35,
      medianIncome: 82000,
      populationDensity: 6200,
      diversityIndex: 0.6,
      educationLevel: 4
    },
    amenities: {
      restaurants: 65,
      cafes: 30,
      gyms: 8,
      parks: 12,
      schools: 8,
      hospitals: 1,
      shopping: 25,
      nightlife: 18
    },
    transportation: {
      walkScore: 78,
      transitScore: 58,
      bikeScore: 72,
      commuteTime: 30
    },
    housing: {
      medianPrice: 720000,
      rentPrice: 2400,
      homeOwnershipRate: 0.45,
      housingTypes: ['single_family', 'condo', 'apartment']
    },
    safety: {
      crimeRate: 32,
      safetyScore: 7
    },
    lifestyle: {
      walkability: 8,
      familyFriendliness: 8,
      nightlifeScore: 7,
      outdoorActivities: 8,
      culturalActivities: 7,
      petFriendliness: 9
    }
  },
  {
    id: '3',
    name: 'Fremont',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6513, lng: -122.3501 },
    demographics: {
      medianAge: 38,
      medianIncome: 78000,
      populationDensity: 5800,
      diversityIndex: 0.65,
      educationLevel: 4
    },
    amenities: {
      restaurants: 45,
      cafes: 25,
      gyms: 6,
      parks: 15,
      schools: 10,
      hospitals: 1,
      shopping: 20,
      nightlife: 12
    },
    transportation: {
      walkScore: 72,
      transitScore: 65,
      bikeScore: 68,
      commuteTime: 28
    },
    housing: {
      medianPrice: 680000,
      rentPrice: 2100,
      homeOwnershipRate: 0.52,
      housingTypes: ['single_family', 'apartment', 'condo']
    },
    safety: {
      crimeRate: 28,
      safetyScore: 8
    },
    lifestyle: {
      walkability: 7,
      familyFriendliness: 9,
      nightlifeScore: 6,
      outdoorActivities: 9,
      culturalActivities: 8,
      petFriendliness: 9
    }
  },
  {
    id: '4',
    name: 'South Lake Union',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6205, lng: -122.3370 },
    demographics: {
      medianAge: 29,
      medianIncome: 95000,
      populationDensity: 12000,
      diversityIndex: 0.8,
      educationLevel: 5
    },
    amenities: {
      restaurants: 55,
      cafes: 35,
      gyms: 15,
      parks: 6,
      schools: 4,
      hospitals: 3,
      shopping: 30,
      nightlife: 20
    },
    transportation: {
      walkScore: 92,
      transitScore: 85,
      bikeScore: 58,
      commuteTime: 15
    },
    housing: {
      medianPrice: 850000,
      rentPrice: 3200,
      homeOwnershipRate: 0.25,
      housingTypes: ['apartment', 'condo', 'luxury']
    },
    safety: {
      crimeRate: 38,
      safetyScore: 7
    },
    lifestyle: {
      walkability: 10,
      familyFriendliness: 4,
      nightlifeScore: 8,
      outdoorActivities: 5,
      culturalActivities: 7,
      petFriendliness: 6
    }
  },
  {
    id: '5',
    name: 'Queen Anne',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6374, lng: -122.3563 },
    demographics: {
      medianAge: 34,
      medianIncome: 88000,
      populationDensity: 7200,
      diversityIndex: 0.7,
      educationLevel: 4
    },
    amenities: {
      restaurants: 70,
      cafes: 40,
      gyms: 10,
      parks: 10,
      schools: 7,
      hospitals: 2,
      shopping: 28,
      nightlife: 22
    },
    transportation: {
      walkScore: 85,
      transitScore: 78,
      bikeScore: 62,
      commuteTime: 20
    },
    housing: {
      medianPrice: 780000,
      rentPrice: 2800,
      homeOwnershipRate: 0.38,
      housingTypes: ['apartment', 'condo', 'single_family']
    },
    safety: {
      crimeRate: 35,
      safetyScore: 7
    },
    lifestyle: {
      walkability: 9,
      familyFriendliness: 7,
      nightlifeScore: 8,
      outdoorActivities: 7,
      culturalActivities: 9,
      petFriendliness: 7
    }
  }
];