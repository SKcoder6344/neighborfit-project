export interface UserPreferences {
  lifestyle: LifestylePreferences;
  demographics: Demographics;
  priorities: Priority[];
}

export interface LifestylePreferences {
  workStyle: 'remote' | 'hybrid' | 'office' | 'flexible';
  transportationMode: 'car' | 'public_transit' | 'bike' | 'walk' | 'mixed';
  socialLevel: number; // 1-5 scale
  activityLevel: number; // 1-5 scale
  nightlife: boolean;
  familyOriented: boolean;
  petFriendly: boolean;
  outdoorActivities: boolean;
}

export interface Demographics {
  ageRange: string;
  incomeRange: string;
  householdSize: number;
  hasChildren: boolean;
  hasPets: boolean;
}

export interface Priority {
  factor: string;
  weight: number; // 1-10 scale
}

export interface Neighborhood {
  id: string;
  name: string;
  city: string;
  state: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  demographics: NeighborhoodDemographics;
  amenities: Amenities;
  transportation: Transportation;
  housing: Housing;
  safety: Safety;
  lifestyle: NeighborhoodLifestyle;
  matchScore?: number;
  matchReasons?: string[];
}

export interface NeighborhoodDemographics {
  medianAge: number;
  medianIncome: number;
  populationDensity: number;
  diversityIndex: number;
  educationLevel: number; // 1-5 scale
}

export interface Amenities {
  restaurants: number;
  cafes: number;
  gyms: number;
  parks: number;
  schools: number;
  hospitals: number;
  shopping: number;
  nightlife: number;
}

export interface Transportation {
  walkScore: number;
  transitScore: number;
  bikeScore: number;
  commuteTime: number; // average in minutes
}

export interface Housing {
  medianPrice: number;
  rentPrice: number;
  homeOwnershipRate: number;
  housingTypes: string[];
}

export interface Safety {
  crimeRate: number; // per 1000 residents
  safetyScore: number; // 1-10 scale
}

export interface NeighborhoodLifestyle {
  walkability: number;
  familyFriendliness: number;
  nightlifeScore: number;
  outdoorActivities: number;
  culturalActivities: number;
  petFriendliness: number;
}

export interface MatchResult {
  neighborhood: Neighborhood;
  score: number;
  breakdown: ScoreBreakdown;
  reasons: string[];
}

export interface ScoreBreakdown {
  lifestyle: number;
  demographics: number;
  amenities: number;
  transportation: number;
  housing: number;
  safety: number;
}